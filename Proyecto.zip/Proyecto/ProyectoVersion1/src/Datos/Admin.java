package Datos;

import LogicaDeNegocios.Prueba;
import java.io.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Admin extends Persona{

    public Admin(String documento, String nombre, String contrasena, String direccion, String telefono, String email) {
        super(documento, nombre, contrasena, direccion, telefono, email);
    } 
    public Admin() {
    }
    public Admin(String documento, String contrasena) {
        super(documento, contrasena);
    }
    
    public ArrayList<Producto> agragarProducto(Producto pro, ArrayList<Producto> pros){
        pros.add(pro);
        return pros;
    }
    
    public ArrayList<Producto> eliminarProducto(Producto pro, ArrayList<Producto> pros){
        pros.remove(pro);
        return pros;
    }
    
    public ArrayList<Producto> modificarProducto(Producto pro,Producto proNuevo, ArrayList<Producto> pros){
        pros.remove(pro);
        pros.add(proNuevo);
        return pros;
    }
    
    public ArrayList<Producto> consultarProducto(String buscador,ArrayList<Producto> pros){
        boolean encontradoExito;
        int longitud = pros.size();
        ArrayList <Producto> encontrados = new ArrayList<Producto>();
        for(int i=0; i<longitud;i++){
            char[] buscadorLetras = buscador.toCharArray();
            int longitudBuscador= buscador.length();
            char[] prosLetars= pros.get(i).getNombre().toCharArray();
            encontradoExito=false;
            for(int j=0; j<longitudBuscador;j++){
                if(buscadorLetras[i]!=prosLetars[i]){
                    encontradoExito=true;
                }else{
                    encontradoExito=false;
                    j=longitudBuscador*2;
                }
            }
            if(encontradoExito==true){
                encontrados.add(pros.get(i));
            }
            
        }
        return encontrados;
    }

    @Override
    public String toString() {
        return documento+"¨"+nombre+"¨"+contrasena+"¨"+direccion+"¨"+telefono+"¨"+email;
    }

    public static void escribirAdmin(Admin nuevo, File archivo){
        try {
            FileWriter fw;
            BufferedWriter bw;
            fw=new FileWriter(archivo);
            bw=new BufferedWriter(fw);
            bw.write(nuevo.toString());
            bw.close();
            fw.close();
        } catch (Exception e) {
            System.out.println("pailas");
            JOptionPane.showMessageDialog(null,"Error al guardar administrador","ERROR", JOptionPane.ERROR_MESSAGE);
        }
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj); //To change body of generated methods, choose Tools | Templates.
    }
    
    public static Admin leerAdmin(File archivo){
        Admin admin = new Admin();
        String [] adminNuevo = new String[6];
        try {
            FileReader fr = new FileReader(archivo);
            BufferedReader br = new BufferedReader(fr);
            String linea;
            while((linea=br.readLine())!= null){
                String [] nuevo = linea.split("¨");
                admin.setDocumento(nuevo[0]);
                admin.setNombre(nuevo[1]);
                admin.setContrasena(nuevo[2]);
                admin.setDireccion(nuevo[3]);
                admin.setTelefono(nuevo[4]);
                admin.setEmail(nuevo[5]);
            }
            br.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null,"Error al cargar Administardor","ERROR", JOptionPane.ERROR_MESSAGE);
        }
        return admin;
    }
}
