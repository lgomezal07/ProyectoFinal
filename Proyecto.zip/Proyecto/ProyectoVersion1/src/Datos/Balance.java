
package Datos;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;

public class Balance{
    private int costos;
    private int ventas;

    public Balance() {
    }

    public Balance(int costos, int ventas) {
        this.costos = costos;
        this.ventas = ventas;
    }

    public int getCostos() {
        return costos;
    }

    public void setCostos(int costos) {
        this.costos = costos;
    }

    

    public int getVentas() {
        return ventas;
    }

    public void setVentas(int ventas) {
        this.ventas = ventas;
    }
    
    public String toString() {
        return costos+"-"+ventas;
    }

    public static void modificarBalance(Balance nuevo, File archivo){
        try {
            FileWriter fw;
            BufferedWriter bw;
            fw=new FileWriter(archivo);
            bw=new BufferedWriter(fw);
            bw.write(nuevo.toString());
            bw.close();
            fw.close();
        } catch (Exception e) {
            System.out.println("pailas");
            JOptionPane.showMessageDialog(null,"Error al guardar ventas","ERROR", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public static Balance leerBalance(File archivo){
        Balance b = new Balance();
        String [] bNuevo = new String[2];
        try {
            FileReader fr = new FileReader(archivo);
            BufferedReader br = new BufferedReader(fr);
            String linea;
            while((linea=br.readLine())!= null){
                String [] nuevo = linea.split("-");
                b.setCostos(Integer.parseInt(nuevo[0]));
                b.setVentas(Integer.parseInt(nuevo[1]));
            }
            br.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null,"Error al cargar Balance","ERROR", JOptionPane.ERROR_MESSAGE);
        }
        return b;
    }
    
}
