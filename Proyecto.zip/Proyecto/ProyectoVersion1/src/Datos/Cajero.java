package Datos;

import java.io.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Cajero extends Persona{
    
    private String sueldo;
    
    public Cajero(String documento, String nombre, String contrasena, String direccion, String telefono, String email,String sueldo) {
        super(documento, nombre, contrasena, direccion, telefono, email);
        this.sueldo = sueldo;
    }
    public String getSueldo() {
        return sueldo;
    }
    public void setSueldo(String sueldo) {
        this.sueldo = sueldo;
    }
    public Cajero(){}
    public Cajero(String documento, String contrasena) {
        super(documento, contrasena);
    }
    
    public ArrayList<Producto> agregarInventario(ArrayList<Producto> pros, int nuevo, String cantidad){
        pros.get(nuevo).setCantidad(cantidad);
        return pros;
    }
    
    public ArrayList<Producto> agotados(ArrayList<Producto> pros){
        int longitud = pros.size();
        ArrayList<Producto> prosAgotados = new ArrayList<Producto>();
        for(int i=0;i<longitud;i++){
            int cantidadAntigua= Integer.parseInt(pros.get(i).getCantidad());
            if(cantidadAntigua<6){
                prosAgotados.add(pros.get(i));
            }
        }
        return prosAgotados;
    }
    
    @Override
    public String toString() {
        return documento+"¨"+nombre+"¨"+contrasena+"¨"+direccion+"¨"+telefono+"¨"+email+"¨"+sueldo;
    }
    
    public static void escribirCajero(Cajero nuevo, File archivo){
        try {
            FileWriter fw;
            BufferedWriter bw;
            fw=new FileWriter(archivo);
            bw=new BufferedWriter(fw);
            bw.write(nuevo.toString());
            bw.close();
            fw.close();
        } catch (Exception e) {
            System.out.println("pailas");
            JOptionPane.showMessageDialog(null,"Error al guardar administrador","ERROR", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public static Cajero leerCajero(File archivo){
        Cajero c = new Cajero();
        try {
            FileReader fr = new FileReader(archivo);
            BufferedReader br = new BufferedReader(fr);
            String linea;
            while((linea=br.readLine())!= null){
                String [] cNuevo = linea.split("¨");
                c.setDocumento(cNuevo[0]);
                c.setNombre(cNuevo[1]);
                c.setContrasena(cNuevo[2]);
               c.setDireccion(cNuevo[3]);
                c.setTelefono(cNuevo[4]);
                c.setEmail(cNuevo[5]);
                c.setSueldo(cNuevo[6]);
            }
            br.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null,"Error al cargar Administardor","ERROR", 
                    JOptionPane.ERROR_MESSAGE);
        }
        return c;
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
