package Datos;

import static LogicaDeNegocios.Prueba.productosArchivo;
import java.io.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Producto {

    public Producto(String nombre, String codigo, String precioVenta, String cantidad) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.precioVenta = precioVenta;
        this.cantidad = cantidad;
    }
    
    private String nombre;
    private String codigo;
    private String precioVenta;
    private String costo;
    private String cantidad;

    public Producto(){}
    public Producto(String nombre, String codigo, String precioVenta, String costo, String cantidad) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.precioVenta = precioVenta;
        this.costo = costo;
        this.cantidad = cantidad;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getCodigo() {
        return codigo;
    }
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    public String getPrecioVenta() {
        return precioVenta;
    }
    public void setPrecioVenta(String precioVenta) {
        this.precioVenta = precioVenta;
    }
    public String getCosto() {
        return costo;
    }
    public void setCosto(String costo) {
        this.costo = costo;
    }
    public String getCantidad() {
        return cantidad;
    }
    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    @Override
    public String toString() {
        return nombre+"--"+ codigo+"--"+ precioVenta +"--"+ costo +"--"+ cantidad ;
    }
    
    public static ArrayList<Producto> agotados(ArrayList<Producto> pros){
        ArrayList<Producto> prosRe = new ArrayList<Producto>();
        for(int i=0;i<pros.size();i++){
            int comparar = Integer.parseInt(pros.get(i).getCantidad());
            if(comparar<6){
                prosRe.add(pros.get(i));
            }
        }
        return prosRe;
    }
    
    public static void nuevoPro(ArrayList<Producto> pros, Producto pro){
        boolean a=true;
        for (int i=0;i<pros.size();i++){
            if(pro.getCodigo().equals(pros.get(i).getCodigo())==true){
                i=pros.size()+3;a=false;
                JOptionPane.showMessageDialog(null, "Codigo igual a otro producto","ERROR",JOptionPane.ERROR_MESSAGE);
            }
        }
        if(a==true){
           pros.add(pro);
           Producto.escribirProducto(pros, productosArchivo);
           JOptionPane.showMessageDialog(null, "Se guardo satisfactoriamente","GUARDAR",JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    public static void escribirProducto(ArrayList<Producto> nuevos, File archivo){
        try {
            FileWriter fw;
            BufferedWriter bw;
            fw=new FileWriter(archivo);
            bw=new BufferedWriter(fw);
            bw.write(nuevos.get(0).toString());
            for(int i=1;i<nuevos.size();i++){
                bw.newLine();
                bw.write(nuevos.get(i).toString());
            }
            bw.close();
            fw.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Error al guardar producto","ERROR", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public static ArrayList<Producto> leerProducto(File archivo){
        ArrayList<Producto> devolver = new ArrayList<Producto>();
        try {
            if(archivo.exists()){
                FileReader fr = new FileReader(archivo);
                BufferedReader br = new BufferedReader(fr);
                String linea;
                while((linea=br.readLine())!= null){
                    String [] nuevo = linea.split("--");
                    Producto p = new Producto();
                    p.setNombre(nuevo[0]);
                    p.setCodigo(nuevo[1]);
                    p.setPrecioVenta(nuevo[2]);
                    p.setCosto(nuevo[3]);
                    p.setCantidad(nuevo[4]);
                    devolver.add(p);
                }
                br.close();
            }
        } catch (IOException e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null,"Error al cargar producto","ERROR", JOptionPane.ERROR_MESSAGE);
        }
        
        return devolver;
    }
    
}
