package LogicaDeNegocios;

import Datos.Admin;
import Datos.Cajero;
import Datos.Producto;
import GUI.CaAgregar;
import GUI.VentanaCajero;
import GUI.VentanaIngreso;
import java.io.*;
import java.util.ArrayList;




public class Prueba {
    
    public static File adminArchivo= new File("C:\\Users\\jpini\\Desktop\\Universidad\\Segundo semestre\\POO\\Taller POO 1\\PuntoDosFinal\\ProyectoVersion1\\src\\Recursos\\admin.txt");
    public static File cajeroArchivo= new File("C:\\Users\\jpini\\Desktop\\Universidad\\Segundo semestre\\POO\\Taller POO 1\\PuntoDosFinal\\ProyectoVersion1\\src\\Recursos\\cajero.txt");
    public static File productosArchivo= new File("C:\\Users\\jpini\\Desktop\\Universidad\\Segundo semestre\\POO\\Taller POO 1\\PuntoDosFinal\\ProyectoVersion1\\src\\Recursos\\productos.txt");
    public static File balanceArchivo = new File("C:\\Users\\jpini\\Desktop\\Universidad\\Segundo semestre\\POO\\Taller POO 1\\PuntoDosFinal\\ProyectoVersion1\\src\\Recursos\\balance.txt");
    
    
    public static void main(String[] args) {
        VentanaIngreso vn = new VentanaIngreso();
        vn.setVisible(true);
        
    }
  
    public static boolean esNumero(String cadena) {

        boolean resultado;

        try {
            Integer.parseInt(cadena);
            resultado = true;
        } catch (NumberFormatException excepcion) {
            resultado = false;
        }

        return resultado;
    }
    
    public static boolean igual(String s1, String s2){
        int b=s2.length()-1;
        boolean y=false;
        char[] s1Arreglo = s1.toCharArray();
        char[] s2Arreglo = s2.toCharArray();
        boolean x = true;
        if(s1.length()==b){
            for(int i=0;i<b;i++){
                if(s1Arreglo[i]!=s2Arreglo[i+1]){
                    x=false;
                    i=100;
                }
            }
            if(x==true){
                y=true;
            }else{
                y=false;
            }
        }else{
            y=false;
        }
        return y;
    }
}
